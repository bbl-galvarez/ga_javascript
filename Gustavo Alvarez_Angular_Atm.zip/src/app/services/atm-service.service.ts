//Gustavo Alvarez service 
//25-04-2018

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AtmInterface } from '../interfaces/AtmInterface';

@Injectable()
export class AtmServiceService {

    private URLWS = "http://localhost:3000/atm/";

    constructor(public http: HttpClient) {
      
    }

    getCurrentBalance(acct : string){
        return this.http.get<AtmInterface>(this.URLWS + acct);
    }

    withDraw(acct : string, amount: number){
        return this.http.get<AtmInterface>(this.URLWS + "withdraw/" + acct + "/amount/" + amount);
    }

    deposit(acct : string, amount: number){
        return this.http.get<AtmInterface>(this.URLWS + "deposit/" + acct + "/amount/" + amount);
    }

    getLastOperations(acct : string){
        return this.http.get<AtmInterface>(this.URLWS + "transactions/" + acct);
    }

}
