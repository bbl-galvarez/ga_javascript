//Gustavo Alvarez App component - 25-04-2018
//Subscribe to observables

import { Component } from '@angular/core';
import {AtmServiceService} from './services/atm-service.service';
import { AtmInterface } from './interfaces/AtmInterface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angluar Gustavo Alvarez with ATM Interface';
  balance = '0';
  acct = '';
  respObs : AtmInterface;

  constructor(public atmService: AtmServiceService){
    atmService.getCurrentBalance("12345-1").subscribe(value =>{
      this.balance = value.getCurrentBalance;
      this.acct = "12345-1";
    })
    
    atmService.withDraw("12345-1", 200).subscribe(value =>{
      this.balance = value.getCurrentBalance;
      this.acct = "12345-1";
    })

    atmService.deposit("12345-1", 300).subscribe(value =>{
      this.balance = value.getCurrentBalance;
      this.acct = "12345-1";
    })

  }

}
